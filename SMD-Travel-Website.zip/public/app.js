const $ = s => document.querySelector(s);
const modal = $("#adminModal"), notice = $("#notice");
$("#year").textContent = new Date().getFullYear();
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url, options={}) {
  const r = await fetch(url, { ...options, headers: { "Content-Type":"application/json", ...(options.headers||{}) } });
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
async function loadUpdates() {
  const items = await api("/api/updates");
  $("#updatesGrid").innerHTML = items.length ? items.map(x => `<article class="update">${x.imageUrl ? `<img src="${esc(x.imageUrl)}" alt="">` : `<div style="height:180px;background:linear-gradient(135deg,#dce9e8,#f0d4a4)"></div>`}<div class="update-body"><div class="meta">${esc(x.location)}${x.date ? " · "+esc(x.date):""}</div><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p></div></article>`).join("") : `<div class="empty">No travel updates published yet. Check back soon!</div>`;
  renderManage(items);
}
function renderManage(items) {
  $("#manageList").innerHTML = items.length ? items.map(x=>`<div class="manage-item"><b>${esc(x.title)}</b> — ${esc(x.location)}<br><button class="outline" data-edit="${esc(x.id)}">Edit</button><button class="outline" data-delete="${esc(x.id)}">Delete</button></div>`).join("") : `<p class="muted">No updates yet.</p>`;
  $("#manageList").querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>editItem(items.find(x=>x.id===b.dataset.edit)));
  $("#manageList").querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(confirm("Delete this update?")){try{await api("/api/updates/"+b.dataset.delete,{method:"DELETE"});await loadUpdates()}catch(e){notice.textContent=e.message}}});
}
function editItem(x){const f=$("#updateForm");for(const k of ["id","title","location","date","imageUrl","description"])f.elements[k].value=x[k]||"";$("#cancelEdit").hidden=false;f.scrollIntoView({behavior:"smooth"});}
function resetForm(){$("#updateForm").reset();$("#updateForm").elements.id.value="";$("#cancelEdit").hidden=true;}
function openModal(){modal.classList.add("show");modal.setAttribute("aria-hidden","false");notice.textContent="";}
function closeModal(){modal.classList.remove("show");modal.setAttribute("aria-hidden","true");}
$("#adminOpen").onclick=async()=>{openModal();try{const s=await api("/api/session");showDashboard(s.loggedIn)}catch{showDashboard(false)}};
$("#closeModal").onclick=closeModal;
modal.addEventListener("click",e=>{if(e.target===modal)closeModal()});
function showDashboard(on){$("#loginPanel").hidden=on;$("#dashboard").hidden=!on;notice.textContent="";if(on)loadUpdates()}
$("#loginForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await api("/api/login",{method:"POST",body:JSON.stringify({username:f.get("username"),password:f.get("password")})});showDashboard(true)}catch(err){notice.textContent=err.message}};
$("#updateForm").onsubmit=async e=>{e.preventDefault();const f=e.target;const body=Object.fromEntries(new FormData(f));const id=body.id;delete body.id;try{await api(id?"/api/updates/"+id:"/api/updates",{method:id?"PUT":"POST",body:JSON.stringify(body)});resetForm();notice.textContent="Update saved.";await loadUpdates()}catch(err){notice.textContent=err.message}};
$("#cancelEdit").onclick=resetForm;
$("#logout").onclick=async()=>{try{await api("/api/logout",{method:"POST"});showDashboard(false);$("#loginForm").reset()}catch(e){notice.textContent=e.message}};
loadUpdates().catch(()=>{$("#updatesGrid").innerHTML='<div class="empty">Unable to load updates right now.</div>'});
