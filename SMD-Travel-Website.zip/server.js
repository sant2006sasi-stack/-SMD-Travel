const express = require("express");
const helmet = require("helmet");
const cookieSession = require("cookie-session");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "updates.json");
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH;
const SESSION_SECRET = process.env.SESSION_SECRET;

if (!ADMIN_PASSWORD_HASH || !SESSION_SECRET) {
  console.error("Set ADMIN_PASSWORD_HASH and SESSION_SECRET in environment variables.");
  process.exit(1);
}

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]", "utf8");

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieSession({
  name: "smd_admin",
  keys: [SESSION_SECRET],
  httpOnly: true,
  sameSite: "lax",
  secure: process.env.NODE_ENV === "production",
  maxAge: 8 * 60 * 60 * 1000
}));
app.use(express.static(path.join(__dirname, "public")));

function readUpdates() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function writeUpdates(items) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2), "utf8");
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.admin === true) return next();
  return res.status(401).json({ error: "Please sign in as admin." });
}

app.get("/api/updates", (_req, res) => {
  const items = readUpdates().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(items);
});
app.get("/api/session", (req, res) => res.json({ loggedIn: !!(req.session && req.session.admin) }));
app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (username !== ADMIN_USER || typeof password !== "string" ||
      !(await bcrypt.compare(password, ADMIN_PASSWORD_HASH))) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  req.session.admin = true;
  res.json({ ok: true });
});
app.post("/api/logout", requireAdmin, (req, res) => {
  req.session = null;
  res.json({ ok: true });
});
app.post("/api/updates", requireAdmin, (req, res) => {
  const { title, location, date, description, imageUrl } = req.body || {};
  if (![title, location, description].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Title, location and description are required." });
  }
  const items = readUpdates();
  const item = {
    id: require("crypto").randomUUID(),
    title: title.trim().slice(0, 100),
    location: location.trim().slice(0, 100),
    date: typeof date === "string" ? date.slice(0, 30) : "",
    description: description.trim().slice(0, 2000),
    imageUrl: typeof imageUrl === "string" && /^https:\/\/\S+$/i.test(imageUrl) ? imageUrl.trim().slice(0, 500) : "",
    createdAt: new Date().toISOString()
  };
  items.push(item);
  writeUpdates(items);
  res.status(201).json(item);
});
app.put("/api/updates/:id", requireAdmin, (req, res) => {
  const items = readUpdates();
  const index = items.findIndex(x => x.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: "Update not found." });
  const { title, location, date, description, imageUrl } = req.body || {};
  if (![title, location, description].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Title, location and description are required." });
  }
  items[index] = {
    ...items[index],
    title: title.trim().slice(0, 100),
    location: location.trim().slice(0, 100),
    date: typeof date === "string" ? date.slice(0, 30) : "",
    description: description.trim().slice(0, 2000),
    imageUrl: typeof imageUrl === "string" && /^https:\/\/\S+$/i.test(imageUrl) ? imageUrl.trim().slice(0, 500) : ""
  };
  writeUpdates(items);
  res.json(items[index]);
});
app.delete("/api/updates/:id", requireAdmin, (req, res) => {
  const items = readUpdates();
  const next = items.filter(x => x.id !== req.params.id);
  if (next.length === items.length) return res.status(404).json({ error: "Update not found." });
  writeUpdates(next);
  res.json({ ok: true });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`SMD Travel running on port ${PORT}`));
