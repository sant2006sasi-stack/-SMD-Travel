# SMD Travel

A responsive travel updates website. Visitors can read updates; there is **no public booking or payment feature**. Only the administrator can add, edit and delete updates.

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Generate a password hash:
   `node -e "console.log(require('bcryptjs').hashSync('YOUR_STRONG_PASSWORD', 12))"`
4. Set environment variables:
   - `ADMIN_USER` = your chosen admin username (default: `admin`)
   - `ADMIN_PASSWORD_HASH` = the hash printed above
   - `SESSION_SECRET` = a long random secret (at least 32 characters)
   - `DATA_DIR` = `./data`
5. Run `npm start` and open `http://localhost:3000`.

## Deploy on Render
1. Upload this project to a private GitHub repository.
2. In Render choose **New + → Web Service**, connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables `ADMIN_USER`, `ADMIN_PASSWORD_HASH`, and `SESSION_SECRET`.
6. For persistent updates, attach a Render persistent disk mounted at `/var/data`, then set `DATA_DIR=/var/data`. Without a persistent disk, stored updates may be lost when the service restarts or redeploys.
7. Deploy. Open your Render URL; use the **Admin** button to sign in.

## Important
- Never share your admin password or `SESSION_SECRET`.
- Use a strong unique admin password.
- Keep the GitHub repository private.
- The admin password is stored as a bcrypt hash, not plain text.
- This starter stores text updates and optional public image URLs; it does not upload image files.
